import React from 'react'
import Navbar from './Components/Navbar'
import NewHero from './Components/NewHero.jsx'
import ThirdSection from './Components/ThirdSection.jsx'
import FourthSection from './Components/FourthSection.jsx'
import FifthSection from './Components/FifthSection.jsx'

const App = () => {
  return (
    <>
    <Navbar/>
    <NewHero/>
    <ThirdSection/>
    <FourthSection/>
    <FifthSection/>
    </>
  )
}

export default App