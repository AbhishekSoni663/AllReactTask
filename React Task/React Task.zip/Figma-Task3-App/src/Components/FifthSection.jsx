import React from 'react'
import "../Components/FifthSection.css"
const FifthSection = () => {
    return (
        <>
            <section className="fifth-bg">
                <div className="container d-flex align-items-end h-100">
                    <div className="fifth-detail d-flex align-items-center  flex-column py-5">
                        <span className='fifth-p'>
                            <p className='text-center text-light fw-medium'>Barbers, tired of
                                chaos? Our app
                                brings smooth booking. Let's simplify salon
                                life, one appointment at a time!
                            </p>
                        </span>
                        <button className='fifth-btn bg-dark text-light border-0 rounded-2'>Parnter With Us</button>
                    </div>
                </div>
            </section>
        </>
    )
}

export default FifthSection