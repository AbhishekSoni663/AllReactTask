import React from 'react'
import "../Components/Navbar.css"
import NavLogo from "../assets/Mask group (3).png"
const Navbar = () => {
    return (
        <>
            <nav className="navbar navbar-expand-md bg-light">
                <div className="container-fluid pe-0">
                    <span className="navabr-logo">
                        <img src={NavLogo} alt="" />
                    </span>
                    <div className="first-nav-box w-75">
                        <div className="first-nav-icons w-100 d-flex justify-content-between align-items-center py-3">
                            <h6 className='w-50 ps-4'>Welcome to Healthcoach</h6>
                            <span className="first-icon w-25 d-flex justify-content-around ">
                                <i class="fa-brands fa-facebook"></i>
                                <i class="fa-brands fa-instagram"></i>
                                <i class="fa-brands fa-twitter"></i>
                                <i class="fa-brands fa-linkedin-in"></i>
                            </span>
                        </div>
                        <div className='first-nav d-flex justify-content-between w-100 py-2 '>
                            <ul className="navbar-nav w-50 d-flex justify-content-between">
                                <li className="nav-item">
                                    <a href="" className="nav-link active">Home</a>
                                </li>
                                <li className="nav-item">
                                    <a href="" className="nav-link active">About</a>
                                </li>
                                <li className="nav-item">
                                    <a href="" className="nav-link active">Service</a>
                                </li>
                                <li className="nav-item">
                                    <a href="" className="nav-link active">Pages</a>
                                </li>
                                <li className="nav-item">
                                    <a href="" className="nav-link active">Contact</a>
                                </li>
                                <li className="nav-item">
                                    <a href="" class="nav-link active"><i
                                        class="fa-solid fa-magnifying-glass"></i></a>
                                </li>

                            </ul>
                            <button className="btn first-nav-btn bg-dark text-light">
                                Book An Appointment
                            </button>
                        </div>
                    </div>
                    <div className="second-nav">
                        <div>
                            <button className="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                                <span className="navbar-toggler-icon" />
                            </button>
                            <div className="offcanvas offcanvas-end" tabIndex={-1} id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                                <div className="offcanvas-header">
                                    <h5 className="offcanvas-title" id="offcanvasNavbarLabel">Offcanvas</h5>
                                    <button type="button" className="btn-close" data-bs-dismiss="offcanvas" aria-label="Close" />
                                </div>
                                <div className="offcanvas-body">
                                    <ul className="navbar-nav justify-content-end flex-grow-1 pe-3">
                                        <li className="nav-item">
                                            <a className="nav-link active" aria-current="page" href="#">Home</a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" href="#">Link</a>
                                        </li>
                                        <li className="nav-item dropdown">
                                            <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                Dropdown
                                            </a>
                                            <ul className="dropdown-menu">
                                                <li><a className="dropdown-item" href="#">Action</a></li>
                                                <li><a className="dropdown-item" href="#">Another action</a></li>
                                                <li>
                                                </li>
                                                <li><a className="dropdown-item" href="#">Something else here</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </nav>
        </>
    )
}

export default Navbar