import React from 'react'
import Navbar from './Components/Navbar'
import Form from './Components/Form'

const App = () => {
  return (
    <>
    <Navbar/>
    <Form/>
    </>
  )
}

export default App