import React from 'react'
import NavLogo from "../assets/img/logo.png"
import NavLogo2 from "../assets/img/Frame (1).png"

const Navbar = () => {
  
  return (
    <>
      <section className="max-w-6xl mx-auto">
        <nav className="border-gray-200">
          <div className="container nav-cont mx-auto flex flex-wrap items-center justify-between pt-[1.9rem]">
            <a href="#" className="flex">
              <span className="logo-img self-center text-lg font-semibold whitespace-nowrap bg-[#D9D9D9] px-5 py-3"><img
                src="./img/logo.png" alt="" className="w-full" />
                <img src="./img/Frame (1).png" className="hidden frame-1 w-full" alt="" /></span>
            </a>

            <button data-collapse-toggle="mobile-menu" type="button" id="menu-toggle"
              className="w-auto md:hidden ml-3 gap-4 text-[#D9A900] hover:text-gray-900 rounded-lg inline-flex items-center justify-center"
              aria-controls="mobile-menu-2" aria-expanded="false">
              <span className="nav-icon-img flex gap-3">
                <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M24 22.7448L17.296 16.0408C18.907 14.1067 19.7104 11.626 19.5389 9.11474C19.3675 6.60346 18.2345 4.25494 16.3756 2.55775C14.5168 0.86055 12.0751 -0.0546524 9.55864 0.00252659C7.04217 0.0597056 4.64462 1.08486 2.86474 2.86474C1.08486 4.64462 0.0597056 7.04217 0.00252659 9.55864C-0.0546524 12.0751 0.86055 14.5168 2.55775 16.3756C4.25494 18.2345 6.60346 19.3675 9.11474 19.5389C11.626 19.7104 14.1067 18.907 16.0408 17.296L22.7448 24L24 22.7448ZM1.80717 9.79659C1.80717 8.21643 2.27574 6.67176 3.15363 5.35791C4.03152 4.04405 5.2793 3.02003 6.73917 2.41533C8.19905 1.81063 9.80545 1.65241 11.3552 1.96069C12.905 2.26896 14.3286 3.02988 15.446 4.14722C16.5633 5.26456 17.3242 6.68814 17.6325 8.23793C17.9408 9.78773 17.7826 11.3941 17.1779 12.854C16.5732 14.3139 15.5491 15.5617 14.2353 16.4395C12.9214 17.3174 11.3767 17.786 9.79659 17.786C7.67838 17.7837 5.64761 16.9412 4.14981 15.4434C2.65202 13.9456 1.80952 11.9148 1.80717 9.79659Z"
                    fill="#D9A900" />
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M12 12.0001C14.21 12.0001 16 10.2101 16 8.00012C16 5.79012 14.21 4.00012 12 4.00012C9.79 4.00012 8 5.79012 8 8.00012C8 10.2101 9.79 12.0001 12 12.0001ZM12 14.0001C9.33 14.0001 4 15.3401 4 18.0001V20.0001H20V18.0001C20 15.3401 14.67 14.0001 12 14.0001Z"
                    fill="#D9A900" />
                </svg>
              </span>
              <span className="sr-only">Open main menu</span>
              <span className="open-menu-icon"><i className="fa-solid fa-bars"></i></span>
            </button>
            <button id="close-toggle" data-collapse-toggle="mobile-menu" type="button"
              className=" hidden w-auto md:hidden ml-3 gap-3 text-[#D9A900] hover:text-gray-900 rounded-lg  items-center justify-center"
              aria-controls="mobile-menu" aria-expanded="true">
              <span className="close-menu-icon  flex justify-end px-2 py-2 items-center">
                <i className="fa-solid fa-xmark text-2xl"></i>
              </span>
            </button>
            <div className="hidden md:block w-full md:w-auto nav-ul-list" id="mobile-menu">
              <button id="close-toggle" data-collapse-toggle="mobile-menu" type="button"
                className="md:hidden  gap-3 text-[#D9A900] hover:text-black rounded-lg flex items-center justify-center w-full"
                aria-controls="mobile-menu" aria-expanded="true">
                <span className="close-menu-icon  w-full flex justify-end px-2 py-2 items-center">
                  <i className="fa-solid fa-xmark text-2xl"></i>
                </span>
              </button>
              <ul className="flex-col md:flex-row flex md:space-x-4 mt-4 md:mt-0 md:text-sm md:font-medium nav-ul">
                <li>
                  <button id="dropdownNavbarLink" data-dropdown-toggle="dropdownNavbar"
                    className="text-black hover:bg-gray-50 border-b border-gray-100 md:hover:bg-transparent md:border-0 pl-3 pr-4 py-2 md:hover:text-[#FF0000] md:p-0 font-bold flex items-center justify-between w-full md:w-auto">
                    Categories
                    <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clipRule="evenodd"></path>
                    </svg>
                  </button>
                  {/* <!-- Dropdown menu --> */}
                  <div id="dropdownNavbar"
                    className="hidden bg-white text-base z-10 list-none divide-y divide-gray-100 rounded shadow my-4  nav-ul-drp">
                    <ul className="py-1" aria-labelledby="dropdownLargeButton">
                      <li>
                        <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Dashboard</a>
                      </li>
                      <li>
                        <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Settings</a>
                      </li>
                      <li>
                        <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Earnings</a>
                      </li>
                    </ul>
                    <div className="py-1">
                      <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Sign out</a>
                    </div>
                  </div>
                </li>
                <li>
                  <button id="dropdownNavbarLink1" data-dropdown-toggle="dropdownNavbar1"
                    className="text-black hover:bg-gray-50 border-b border-gray-100 md:hover:bg-transparent md:border-0 pl-3 pr-4 py-2 md:hover:text-[#FF0000] md:p-0 font-bold flex items-center justify-between w-full md:w-auto">
                    Blogs
                    <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clipRule="evenodd"></path>
                    </svg>
                  </button>
                  {/* <!-- Dropdown menu --> */}
                  <div id="dropdownNavbar1"
                    className="hidden bg-white text-base z-10 list-none divide-y divide-gray-100 rounded shadow my-4  nav-ul-drp1">
                    <ul className="py-1 w-full" aria-labelledby="dropdownLargeButton">
                      <li>
                        <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Dashboard</a>
                      </li>
                      <li>
                        <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Settings</a>
                      </li>
                      <li>
                        <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Earnings</a>
                      </li>
                    </ul>
                    <div className="py-1">
                      <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Sign out</a>
                    </div>
                  </div>
                </li>
                <li>
                  <button id="dropdownNavbarLink2" data-dropdown-toggle="dropdownNavbar2"
                    className="font-bold text-black hover:bg-gray-50 border-b border-gray-100 md:hover:bg-transparent md:border-0 pl-3 pr-4 py-2 md:hover:text-[#FF0000] md:p-0 flex items-center justify-between w-full md:w-auto">
                    About
                    <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clipRule="evenodd"></path>
                    </svg>
                  </button>
                  {/* <!-- Dropdown menu --> */}
                  <div id="dropdownNavbar2"
                    className="hidden bg-white text-base z-10 list-none divide-y divide-gray-100 rounded shadow my-4  nav-ul-drp2">
                    <ul className="py-1" aria-labelledby="dropdownLargeButton">
                      <li>
                        <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Dashboard</a>
                      </li>
                      <li>
                        <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Settings</a>
                      </li>
                      <li>
                        <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Earnings</a>
                      </li>
                    </ul>
                    <div className="py-1">
                      <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Sign out</a>
                    </div>
                  </div>
                </li>
                <li>
                  <button id="dropdownNavbarLink3" data-dropdown-toggle="dropdownNavbar3"
                    className="text-black hover:bg-gray-50 border-b border-gray-100 md:hover:bg-transparent md:border-0 pl-3 pr-4 py-2 md:hover:text-[#FF0000] md:p-0 font-bold flex items-center justify-between w-full md:w-auto">
                    Pages
                    <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clipRule="evenodd"></path>
                    </svg>
                  </button>
                  {/* <!-- Dropdown menu --> */}
                  <div id="dropdownNavbar3"
                    className="hidden bg-white text-base z-10 list-none divide-y divide-gray-100 rounded shadow my-4  nav-ul-drp3">
                    <ul className="py-1" aria-labelledby="dropdownLargeButton">
                      <li>
                        <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Dashboard</a>
                      </li>
                      <li>
                        <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Settings</a>
                      </li>
                      <li>
                        <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Earnings</a>
                      </li>
                    </ul>
                    <div class="py-1">
                      <a href="#" className="text-sm hover:bg-gray-100 text-gray-700 block px-4 py-2">Sign out</a>
                    </div>
                  </div>
                </li>
                <li>
                  <a href="#"
                    className="text-black hover:bg-gray-50 border-b border-gray-100 md:hover:bg-transparent md:border-0 block pl-3 pr-4 py-2 md:hover:text-[#FF0000] md:p-0">Login</a>
                </li>
                <li>
                  <a href="#"
                    className="text-black hover:bg-gray-50 border-b border-gray-100 md:hover:bg-transparent md:border-0 block pl-3 pr-4 py-2 md:hover:text-[#FF0000] md:p-0">Register</a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </section>
    </>
  )
}

export default Navbar