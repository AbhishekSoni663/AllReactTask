import React from 'react'
import Navbar from './Component/Navbar'

const App = () => {
  return (
<>
<section className="main-section max-w-[1920px]">
<Navbar/>
</section>
</>
  )
}

export default App